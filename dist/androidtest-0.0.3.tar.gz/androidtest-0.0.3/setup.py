#!/usr/bin/env python

from distutils.core import setup

setup(
    name='androidtest',
    version='0.0.3',
    packages=['androidtest'],
    url='https://github.com/lizongzi/androidtest',
    license='1.0',
    author='lizongzhi',
    author_email='136313283@qq.com',
    description='基于adb的安卓自动化操作'
)
